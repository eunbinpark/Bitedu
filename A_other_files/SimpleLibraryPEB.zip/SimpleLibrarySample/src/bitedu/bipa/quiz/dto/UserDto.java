package bitedu.bipa.book.Sample.SimpleLibrarySample.src.bitedu.bipa.quiz.dto;

public class UserDto {
    private int user_id;
    private String user_name;
    private String user_phone;
}
